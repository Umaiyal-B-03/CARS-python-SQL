class Case:
    def __init__(self, case_id: int, description: str, incidents: list):
        self.case_id = case_id
        self.description = description
        self.incidents = incidents
