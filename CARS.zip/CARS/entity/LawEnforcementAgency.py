class LawEnforcementAgency:
    def __init__(self, agency_id: int, agency_name: str, jurisdiction: str, contact_information: str):
        self.agency_id = agency_id
        self.agency_name = agency_name
        self.jurisdiction = jurisdiction
        self.contact_information = contact_information
