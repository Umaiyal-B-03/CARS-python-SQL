class Incident:
    def __init__(self, incident_id: int, incident_type: str, incident_date: str,
                 location: str, description: str, status: str, victim_id: int, suspect_id: int):
        self.incident_id = incident_id
        self.incident_type = incident_type
        self.incident_date = incident_date
        self.location = location
        self.description = description
        self.status = status
        self.victim_id = victim_id
        self.suspect_id = suspect_id


    def __repr__(self):
        return f"Incident(ID={self.incident_id}, Type={self.incident_type}, Date={self.incident_date})"
