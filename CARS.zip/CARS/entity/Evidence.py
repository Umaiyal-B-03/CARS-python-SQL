class Evidence:
    def __init__(self, evidence_id: int, description: str, location_found: str, incident_id: int):
        self.evidence_id = evidence_id
        self.description = description
        self.location_found = location_found
        self.incident_id = incident_id
