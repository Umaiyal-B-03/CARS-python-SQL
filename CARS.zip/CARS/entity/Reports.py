class Report:
    def __init__(self, report_id: int, incident_id: int, reporting_officer: int,
                 report_date: str, report_details: str, status: str):
        self.report_id = report_id
        self.incident_id = incident_id
        self.reporting_officer = reporting_officer
        self.report_date = report_date
        self.report_details = report_details
        self.status = status

