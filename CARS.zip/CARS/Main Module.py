import sys
from datetime import datetime
sys.path.append(r"C:\CARS")

from dao.CrimeAnalysisServiceImpl import CrimeAnalysisServiceImplementation
from entity.Incidents import Incident
from entity.Reports import Report
from entity.Case import Case
from myexceptions.IncidentNumberNotFoundException import IncidentNumberNotFoundException

def main():
    service = CrimeAnalysisServiceImplementation()

    while True:
        print("\n ------------CRIME ANALYSIS REPORTING SYSTEM----------------")
        print("1. Create Incident")
        print("2. Update Incident Status")
        print("3. Search Incidents by Type")
        print("4. View Incidents in Date Range")
        print("5. Generate Incident Report")
        print("6. Create Case")
        print("7. Get Case Details")
        print("8. Update Case Details")
        print("9. Exit")

        choice = input("Enter your choice: ")

        if choice == "1":
            try:
                incident_id = int(input("Incident ID: "))
                incident_type = input("Incident Type: ")
                incident_date = input("Incident Date (YYYY-MM-DD): ")
                location = input("Location: ")
                description = input("Description: ")
                status = input("Status: ")
                victim_id = int(input("Victim ID: "))
                suspect_id = int(input("Suspect ID: "))
                incident = Incident(incident_id, incident_type, incident_date, location, description, status, victim_id, suspect_id)
                result = service.createIncident(incident)
                print("Incident created successfully." if result else "Failed to create incident.")
            except Exception as e:
                print("Error creating incident:", e)

        elif choice == "2":
            try:
                incident_id = int(input("Incident ID to update: "))
                new_status = input("New Status: ")
                incidents = service.searchIncidents("")
                if not any(i.incident_id == incident_id for i in incidents):
                    raise IncidentNumberNotFoundException(incident_id)
                updated = service.updateIncidentStatus(new_status, incident_id)
                print("Status updated." if updated else "Update failed.")
            except IncidentNumberNotFoundException as e:
                print(e)
            except Exception as e:
                print("Error updating status:", e)


        elif choice == "3":
            try:
                inc_type = input("Enter incident type to search: ")
                incidents = service.searchIncidents(inc_type)
                if incidents:
                    for inc in incidents:
                        print(vars(inc))
                else:
                    print("No incidents found.")
            except Exception as e:
                print("Error searching incidents:", e)

        elif choice == "4":
            try:
                start = input("Start date (YYYY-MM-DD): ")
                end = input("End date (YYYY-MM-DD): ")
                incidents = service.getIncidentsinDateRange(datetime.strptime(start, "%Y-%m-%d"), datetime.strptime(end, "%Y-%m-%d"))
                for i in incidents:
                    print(vars(i))
            except Exception as e:
                print("Error fetching incidents:", e)

        elif choice == "5":
            try:
                incident_id = int(input("Enter Incident ID: "))
                incident = Incident(incident_id, None, None, None, None, None, None, None)
                reports = service.generateIncidentReport(incident)
                if not reports:
                    raise IncidentNumberNotFoundException(incident_id)
                else:
                    for r in reports:
                        print(vars(r))
            except IncidentNumberNotFoundException as e:
                print(e)
            except Exception as e:
                print("Error generating report:", e)

        elif choice == "6":
            try:
                desc = input("Case description: ")
                inc_type = input("Type of incidents to add in case: ")
                incidents = service.searchIncidents(inc_type)

                if not incidents:
                    print("No incidents found with this type. Case not created.")
                    continue

                case = service.createCase(desc, incidents)
                print("Case created successfully.")
                for c in case:
                    print(f"\nCase ID: {c.case_id}, Description: {c.description}")
                    print("Associated Incidents:")
                for i in c.incidents:
                    print(f"  Incident ID: {i.incident_id}, Type: {i.incident_type}")

            except Exception as e:
                print("Error creating case:", e)

        elif choice == "7":
            try:
                case_id = int(input("Case ID: "))
                desc = input("Case description: ")
                inc_type = input("Incident type for this case: ")
                incidents = service.searchIncidents(inc_type)
                details = service.getCaseDetails(case_id, desc, incidents)
                print("Case details:", [vars(d) for d in details])
            except Exception as e:
                print("Error getting case details:", e)

        elif choice == "8":
            try:
                case_id = int(input("Case ID: "))
                desc = input("New description: ")
                inc_type = input("Incident type to update: ")
                incidents = service.searchIncidents(inc_type)
                case = Case(case_id, desc, incidents)
                result = service.updateCaseDetails(case)
                print("Case updated." if result else "Case update failed.")
            except Exception as e:
                print("Error updating case:", e)

        elif choice == "9":
            print("EXITING CRIME ANALYSIS REPORTING SYSTEM....THANK YOU!")
            break

        else:
            print("Invalid option. Please try again.")

if __name__ == "__main__":
    main()
