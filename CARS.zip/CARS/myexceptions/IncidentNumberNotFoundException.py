import sys
sys.path.append(r"C:\CARS") 

class IncidentNumberNotFoundException(Exception):
    def __init__(self, incident_id=None):
        message = f"Incident number {incident_id} not found in the database." if incident_id else "Incident number not found."
        super().__init__(message)

    def __str__(self):
        return f"IncidentNumberNotFoundException: {self.args[0]}"
