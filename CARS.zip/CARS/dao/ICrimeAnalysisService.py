from typing import List
from datetime import datetime
from abc import ABC,abstractmethod
import sys
sys.path.append(r"C:\CARS")

from entity.Incidents import Incident
from entity import Suspects
from entity import Victims
from entity import LawEnforcementAgency
from entity import Officers
from entity import Evidence
from entity.Reports import Report
from entity import Case



class ICrimeAnalysisService(ABC):
    @abstractmethod
    def createIncident(self,incident:Incident)-> bool:
        pass

    @abstractmethod
    def updateIncidentStatus(self,status:str ,incidentID:int )-> bool:
        pass

    @abstractmethod
    def getIncidentsinDateRange(self,startDate:datetime,endDate:datetime)-> List[Incident]:
        pass

    @abstractmethod
    def searchIncidents(self,incidenttype:str)-> List[Incident]:
        pass

    @abstractmethod
    def generateIncidentReport(self,incident:Incident)-> List[Report]:
        pass

    @abstractmethod
    def createCase(self,caseDescription:str ,incidents: List[Incident])-> List[Case]:
        pass

    @abstractmethod
    def getCaseDetails(self,case_id:int,caseDescription:str,incidents: List[Incident])-> List[Case]:
        pass

    @abstractmethod
    def updateCaseDetails(self,case:Case)-> bool:
        pass
    
    @abstractmethod
    def getAllCases(self)-> List[Case]:
        pass







