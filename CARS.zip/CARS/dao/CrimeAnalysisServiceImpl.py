import sys
sys.path.append(r"C:\CARS")  


from util.DBConnectionUtil import DBConnection 
from dao.ICrimeAnalysisService import ICrimeAnalysisService
from entity.Incidents import Incident
from entity.Officers import Officer
from entity.Case import Case
from entity.Evidence import Evidence
from entity.Suspects import Suspect
from entity.Victims import Victim
from entity.LawEnforcementAgency import LawEnforcementAgency
from entity.Reports import Report
from typing import Collection
from datetime import datetime

class CrimeAnalysisServiceImplementation(ICrimeAnalysisService):
    def __init__(self):
        self.connection = DBConnection.getConnection()


  
    def createIncident(self, incident: Incident):
        cursor = self.connection.cursor()
        try:
            cursor.execute("""
                INSERT INTO Incidents(IncidentID, IncidentType, IncidentDate, Location, Description, Status, VictimID, SuspectID)VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """, (incident.incident_id, incident.incident_type, incident.incident_date, incident.location,incident.description, incident.status, incident.victim_id, incident.suspect_id))
            self.connection.commit()
            return True
        except Exception as e:
            print("Error inserting Incident:",e)
            return False


    def updateIncidentStatus(self, status: str, incidentID: int):
        cursor = self.connection.cursor()
        try:
            cursor.execute("UPDATE Incidents SET Status = ? WHERE IncidentID = ?", (status, incidentID))
            self.connection.commit()
            if cursor.rowcount == 0:
                return False  
            return True
        except Exception as e:
            print("Error updating status:", e)
            return False



    def getIncidentsinDateRange(self, startDate: datetime, endDate: datetime) -> Collection[Incident]:
        cursor = self.connection.cursor()
        try:
            cursor.execute("SELECT * FROM Incidents WHERE IncidentDate BETWEEN ? AND ?", (startDate, endDate))
            rows = cursor.fetchall()
            return [Incident(*row) for row in rows]
        except Exception as e:
            print("Error fetching incidents:",e)
            return False


   
    def searchIncidents(self, incidenttype: str) -> Collection[Incident]:
        cursor = self.connection.cursor()
        try:
            cursor.execute("SELECT * FROM Incidents WHERE IncidentType = ?", (incidenttype,))
            rows = cursor.fetchall()
            return [Incident(*row) for row in rows]
        except Exception as e:
            print("Error searching incidents:",e)
            return False


 
    def generateIncidentReport(self, incident: Incident) -> Collection[Report]:
        cursor = self.connection.cursor()
        try:
            cursor.execute("SELECT * FROM Reports WHERE IncidentID = ?", (incident.incident_id,))
            rows = cursor.fetchall()
            return [Report(*row) for row in rows]
        except Exception as e:
            print("Error generating report:",e)
            return False


 
    def createCase(self, caseDescription: str, incidents: Collection[Incident]) -> Collection[Case]:
        try:
            case_id = id(caseDescription + str(datetime.now()))
            return [Case(case_id, caseDescription, list(incidents))]
        except Exception as e:
            print("Error creating case:",e)
            return False


   
    def getCaseDetails(self, case_id: int, caseDescription: str, incidents: Collection[Incident]) -> Collection[Case]:
        try:
            return [Case(case_id, caseDescription, list(incidents))]
        except Exception as e:
            print("Error getting case details:",e)
            return False



    def updateCaseDetails(self, case: Case):
        try:
            print(f"Case updated: {case.case_id}")
            return True
        except Exception as e:
            print("Error updating case:",e)
            return False


    
    def getAllCases(self) -> Collection[Case]:
        try:
            return [] 
        except Exception as e:
            print("Error retrieving cases:",e)
            return False

