import sys
sys.path.append(r"C:\CARS")

import unittest
from entity.Incidents import Incident
from dao.CrimeAnalysisServiceImpl import CrimeAnalysisServiceImplementation

class TestIncidentCreation(unittest.TestCase):
    def test_create_incident_and_attributes(self):
        service = CrimeAnalysisServiceImplementation()
        incident = Incident(129, "Theft", "2024-06-28", "Mall", "Phone stolen", "Open", 1, 2)
        self.assertTrue(service.createIncident(incident))
        self.assertEqual(incident.location, "Mall")

unittest.main()
