
import sys
sys.path.append(r"C:\CARS")

import unittest
from entity.Incidents import Incident
from dao.CrimeAnalysisServiceImpl import CrimeAnalysisServiceImplementation

class TestIncidentStatusUpdate(unittest.TestCase):
    def test_valid_and_invalid_status_update(self):
        service = CrimeAnalysisServiceImplementation()
        self.assertTrue(service.updateIncidentStatus("Closed", 108))  
        self.assertFalse(service.updateIncidentStatus("Closed", 9999)) 


unittest.main()
