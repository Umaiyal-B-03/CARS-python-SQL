import pyodbc
import sys
sys.path.append(r"C:\CARS")

from util.PropertyUtil import PropertyUtil 

class DBConnection:
    @staticmethod
    def getConnection():
        connection_string=PropertyUtil.getPropertyString()
        return pyodbc.connect(connection_string)
