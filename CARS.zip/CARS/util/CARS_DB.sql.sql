USE [CARS]
GO
/****** Object:  Table [dbo].[Suspects]    Script Date: 06/30/2025 21:41:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Suspects](
	[SuspectID] [int] NOT NULL,
	[FirstName] [varchar](50) NULL,
	[LastName] [varchar](50) NULL,
	[DateOfBirth] [datetime] NULL,
	[Contact_Information] [varchar](70) NULL,
PRIMARY KEY CLUSTERED 
(
	[SuspectID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Law_Enforcement_Agencies]    Script Date: 06/30/2025 21:41:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Law_Enforcement_Agencies](
	[AgencyID] [int] NOT NULL,
	[AgencyName] [varchar](50) NULL,
	[Jurisdiction] [varchar](100) NULL,
	[Contact_Information] [varchar](70) NULL,
PRIMARY KEY CLUSTERED 
(
	[AgencyID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Victims]    Script Date: 06/30/2025 21:41:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Victims](
	[VictimID] [int] NOT NULL,
	[FirstName] [varchar](50) NULL,
	[LastName] [varchar](50) NULL,
	[DateOfBirth] [datetime] NULL,
	[Gender] [varchar](50) NULL,
	[Contact_Information] [varchar](70) NULL,
PRIMARY KEY CLUSTERED 
(
	[VictimID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Incidents]    Script Date: 06/30/2025 21:41:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Incidents](
	[IncidentID] [int] NOT NULL,
	[IncidentType] [varchar](50) NULL,
	[IncidentDate] [datetime] NULL,
	[Location] [varchar](100) NULL,
	[Description] [varchar](60) NULL,
	[Status] [varchar](50) NULL,
	[VictimID] [int] NULL,
	[SuspectID] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[IncidentID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Evidence]    Script Date: 06/30/2025 21:41:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Evidence](
	[EvidenceID] [int] NOT NULL,
	[Description] [varchar](60) NULL,
	[LocationFound] [varchar](50) NULL,
	[IncidentID] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[EvidenceID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Reports]    Script Date: 06/30/2025 21:41:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Reports](
	[ReportID] [int] NOT NULL,
	[IncidentID] [int] NULL,
	[ReportingOfficer] [int] NULL,
	[ReportDate] [datetime] NULL,
	[ReportDetails] [varchar](70) NULL,
	[Status] [varchar](50) NULL,
PRIMARY KEY CLUSTERED 
(
	[ReportID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Officers]    Script Date: 06/30/2025 21:41:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Officers](
	[OfficerID] [int] NOT NULL,
	[FirstName] [varchar](50) NULL,
	[LastName] [varchar](50) NULL,
	[BadgeNumber] [int] NULL,
	[Rank] [int] NULL,
	[Contact_Information] [varchar](70) NULL,
	[AgencyID] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[OfficerID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  ForeignKey [FK__Evidence__Incide__0CBAE877]    Script Date: 06/30/2025 21:41:19 ******/
ALTER TABLE [dbo].[Evidence]  WITH CHECK ADD FOREIGN KEY([IncidentID])
REFERENCES [dbo].[Incidents] ([IncidentID])
GO
/****** Object:  ForeignKey [FK__Incidents__Suspe__0519C6AF]    Script Date: 06/30/2025 21:41:19 ******/
ALTER TABLE [dbo].[Incidents]  WITH CHECK ADD FOREIGN KEY([SuspectID])
REFERENCES [dbo].[Suspects] ([SuspectID])
GO
/****** Object:  ForeignKey [FK__Incidents__Suspe__1367E606]    Script Date: 06/30/2025 21:41:19 ******/
ALTER TABLE [dbo].[Incidents]  WITH CHECK ADD FOREIGN KEY([SuspectID])
REFERENCES [dbo].[Suspects] ([SuspectID])
GO
/****** Object:  ForeignKey [FK__Incidents__Victi__0425A276]    Script Date: 06/30/2025 21:41:19 ******/
ALTER TABLE [dbo].[Incidents]  WITH CHECK ADD FOREIGN KEY([VictimID])
REFERENCES [dbo].[Victims] ([VictimID])
GO
/****** Object:  ForeignKey [FK__Officers__Agency__09DE7BCC]    Script Date: 06/30/2025 21:41:19 ******/
ALTER TABLE [dbo].[Officers]  WITH CHECK ADD FOREIGN KEY([AgencyID])
REFERENCES [dbo].[Law_Enforcement_Agencies] ([AgencyID])
GO
/****** Object:  ForeignKey [FK__Reports__Inciden__0F975522]    Script Date: 06/30/2025 21:41:19 ******/
ALTER TABLE [dbo].[Reports]  WITH CHECK ADD FOREIGN KEY([IncidentID])
REFERENCES [dbo].[Incidents] ([IncidentID])
GO
/****** Object:  ForeignKey [FK__Reports__Reporti__108B795B]    Script Date: 06/30/2025 21:41:19 ******/
ALTER TABLE [dbo].[Reports]  WITH CHECK ADD FOREIGN KEY([ReportingOfficer])
REFERENCES [dbo].[Officers] ([OfficerID])
GO
