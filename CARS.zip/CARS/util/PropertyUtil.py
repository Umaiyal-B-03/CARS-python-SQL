import sys
sys.path.append(r"C:\CARS")

import pyodbc
driver_name="SQL Server"
server="DESKTOP-C10P6IV\\SQLEXPRESS"
database="CARS"
username="sa"
password="abc"


class PropertyUtil:
    @staticmethod
    def getPropertyString():
        connection_string=(f'Driver={driver_name};Server={server};Database={database};Trusted_connection=yes;')
        return connection_string  
